Kattis link: https://ru.kattis.com/courses/T-111-PROG/PROG24/assignments/scgs4q/submissions/14813184
Submission ID: 14813184