Submission ID: 14665443

Linkur: https://ru.kattis.com/courses/T-111-PROG/PROG24/assignments/uyb45f/submissions/14665443